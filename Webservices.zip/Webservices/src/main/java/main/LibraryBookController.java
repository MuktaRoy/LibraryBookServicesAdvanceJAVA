package main;


import model.LibraryBook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class LibraryBookController {


    @Autowired
    private LibraryBookService libraryBookService;

    @RequestMapping("/LibraryBooks")
    public List<LibraryBook> getAllLibraryBooks() {
        return libraryBookService.getAllLibraryBooks();
    }


@RequestMapping("/LibraryBooks/(indexNumber)")
    public LibraryBook getLibraryBook(@PathVariable String indexNumber)
    {
        return libraryBookService.getLibraryBook(indexNumber);
   }

@RequestMapping(method = RequestMethod.POST, value = "/libraryBooks")
public void addLibraryBook(@RequestBody LibraryBook libraryBook)
{
  libraryBookService.addLibraryBook(libraryBook);
}
@RequestMapping(method = RequestMethod.PUT, value = "/libraryBooks/(id)")
public void updateLibraryBook(@RequestBody LibraryBook libraryBook, @PathVariable String indexNumber)
{
libraryBookService.updateLibraryBook(libraryBook,indexNumber);
}

    @RequestMapping(method = RequestMethod.DELETE, value = "/libraryBooks/(id)")
    public void deleteLibraryBook(@RequestBody LibraryBook libraryBook, @PathVariable String indexNumber)
    {
        libraryBookService.deleteLibraryBook(libraryBook,indexNumber);
    }

}




